// VideoBackground.js

import React from 'react';
import './VideoBackground.css';

const VideoBackground = () => {
  return (
    <div className="video-background">
		<iframe 
			src="https://cdn.dribbble.com/userupload/3271265/file/original-7456a2b72296602769d1283748a0b523.m4v">
		</iframe>
    </div>
  );
};

export default VideoBackground;
